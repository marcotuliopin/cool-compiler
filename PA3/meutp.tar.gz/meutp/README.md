
## Seção 2 : Analisador Sintático

**Marco Túlio de Pinho e Raul Araju**

Dividimos a documentação dessa seção na explicação das definições dos terminais e das regras implementadas para o Analisdor sintático.

--------------------------
### Terminais

Começamos nossas com a declaração dos terminais e dos seus tipos:
- **%type \<feature> feat** : define a feature de uma classe.
- **%type \<features> feat_list** : define uma lista de features de uma classe.
- **%type \<feature> attr** : o atributo de uma classe é uma feature dela.
- **%type \<feature> method** : o método de uma classe é uma feature dela.
 - **%type \<formal> formal**: define o parâmetro formal.
 - **%type \<formals> formal_list**: define uma lista de parâmetros formais.
 - **%type \<cases> case_list**: define uma lista de casos de uma estrutura *case*.    
 -  **%type \<expression> expr**: define uma      
   expressão.    
  - **%type \<expressions> expr_list**: define uma lista de
   expressões separadas por ' , '.   
   - **%type \<expressions> expr_list_1**: define uma lista de expressões separadas por ' ; '.   
 -  **%type \<expression> let**: define uma estrutura *let*.    
 - **%type \<expression> init**: define a estrutura de uma inicialização de uma 
   variável.

--------------------------
### Regras
 As regras foram baseadas na documentação da linguagem COOL, bem como nos métodos definidos no arquivo *cool-tree.cc*.

#### feat
Uma feature pode ser um atributo ou um método.

#### feat_list
Adiciona cada feature à lista até que não haja mais features a serem adicionadas. Uma lista sem features é uma lista de features.

#### attr
Um atributo é da forma : \<id1> :\<tipo> [ <- \<expr> ]

#### method
Um método é da forma \<id>(\<id> : \<type>,...,\<id> : \<type>): \<type> { \<expr> };

#### formal

Um parâmetro formal é da forma: \<id> : \<tipo>.

#### formal_list
Para cada parâmetro formal lido após um *,*, adiciona ele à lista. Nesse caso, uma lista sem parâmetros é uma lista de parâmetros.

#### case
Uma linha do tipo \<id> : \<tipo> => \<expr>;. Adicionamos uma *branch* nesse caso.

#### case_list
Para cada linha da forma: \<id> : \<tipo> => \<expr>;, adiciona um *case* à lista. Nesse caso, uma lista sem parâmetros é uma lista de *case*s.

####  expr
As expressões são a maior categoria sintática do COOL, então há muitas regras relacionadas a elas. De maneira geral, para cada método no arquivo *cool-tree.cc* que retorna um objeto da classe Expression, criou-se uma regra apropriada relacionada a esse método. Por exemplo, para as contantes, criaram-se 3 regras que usaram os métodos: int_const, string_const e bool_const.

#### expr_list

Para cada expressão lida após um *,*, adiciona ela à lista. Nesse caso, uma lista sem expressões é uma lista de expressões.

#### expr_list1

Para cada expressão lida após um *;*, adiciona ela à lista. Nesse caso, uma lista deve ter pelo menos uma  lista de expressões.

#### let

Na declarações de precedência e de associatividade, foi criado um token *LET_REC*. Esse token foi usado na regra para definir precedência e solucionar o conflito de shift-reduce, introduzido pela ambiguidade da gramática. Além disso, um tratamento de erro é aplicado para que caso ocorra um erro de um let em uma variável, o parser siga para a próxima variável.
case_list.

#### init

Essa regra define uma inicialização opcional da variável.

### Erros

Adicionamos uma regra de reconhecimento de erros em *features*, de forma que, caso haja um erro em uma *feature*, o parser segue para a próxima *feature*. Além disso, tratamos de erros em *blocks* (definidos conforme *expr_list1*, invocando a macro *yyerrok*. O mesmo tratamento é realizado para expressões apresentando erro na definição de um *let*. Por fim, uma classe que apresenta erro também é tratada conforme a macro *yyerrok*.

## Good.cl
Definições de Classe: O código define uma classe chamada  C. Isso demonstra o conceito de definições de classe.

Atributos: Ele inclui um atributo var: Int dentro da classe C, mostrando declarações de atributos.

Métodos: A classe C define alguns métodos, incluindo method0, method1, method2 etc. Esses métodos ilustram definições de métodos.

Parâmetros de Método: Os métodos method0 e method1, por exemplo, recebem parâmetros (num1, num2, num), destacando os parâmetros de método em COOL.

Variáveis Locais: Os métodos declaram variáveis locais usando a expressão let, como let y: Int <- 1, o que demonstra declarações de variáveis.

Operações Aritméticas: O método add realiza uma operação aritmética, x * y, para mostrar expressões matemáticas em COOL.

Declarações Condicionais: O método method2 declarações condicionais (if...then...else...fi) para demonstrar construções de fluxo de controle.

Expressão Case: O método method3 usa uma expressão case para verificar o tipo dinâmico de um objeto, cobrindo a expressão case do COOL.

Herança: A classe B herda da classe A, ilustrando a herança de classes no COOL.

Instanciação de Objetos (New): O método method1 usa a expressão new B para criar um novo objeto, destacando a instanciação de objetos.

### Bad.cl

Nome do Método Ausente: Na classe Principal, o método principal está sem um nome após o parêntese de abertura. Esse erro representa um erro comum ao definir um método.

Dois Pontos Ausentes Após o Nome do Método: No método "add" dentro da classe Principal, não há dois pontos (:) após o nome do método. Isso representa uma violação da sintaxe de declaração de método.

Falta de <- para Atribuição de Atributo: No atributo "a" da classe Principal, o operador <- para atribuição de atributo foi substituído por um sinal de igual (=). Isso demonstra a maneira incorreta de inicializar atributos.

Parênteses não Correspondentes: No método "if_example" da classe Principal, há um parêntese de abertura não correspondente na instrução "if", que não está sendo fechado corretamente. Esse erro representa um erro comum de sintaxe em instruções condicionais.

Chaves não Correspondentes: No método "while_example" da classe Principal, a chave de abertura do loop "while" não está sendo fechada com a palavra-chave "pool" corretamente. Isso demonstra a importância do emparelhamento adequado de chaves em estruturas de controle.

Uso de Tipo Desconhecido: No método "let_example" da classe Principal, um tipo desconhecido, "UnknownType," é usado em uma declaração de variável. Isso destaca o problema de usar tipos indefinidos em COOL.

Definição de Classe Incompleta: O código inclui a classe "IncompleteClass," que não possui uma chave de fechamento para encerrar adequadamente a definição da classe. Isso representa um erro comum ao definir classes.
